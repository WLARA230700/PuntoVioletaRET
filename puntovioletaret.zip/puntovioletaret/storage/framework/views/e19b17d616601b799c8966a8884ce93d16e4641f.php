<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css%22%3E">
    <title>Inicio - Punto Violeta</title>
</head>
<body>
    <!-- TOP NAV -->
        <h1>PUNTO VIOLETA</h1>
    <!-- TOP NAV -->

    <section>
        <?php echo $__env->yieldContent('content'); ?>
    </section>

    <!-- FOTTER -->

    <!-- FOTTER -->
</body>
</html><?php /**PATH B:\laragon\www\puntovioletaret\resources\views/layout_usuario.blade.php ENDPATH**/ ?>