<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/style.css">
    <title>Inicio - Punto Violeta</title>
</head>

<body>

    <section class="container-fluid min-height">

        <nav class="nav-logo-admin">
            <a class="logo-nav" href="#"><span>PUNTO VIOLETA</span></a>
            <a class="signout" href="<?php echo e(route('signout')); ?>">Cerrar sesión</a>
        </nav>

        <!-- DASHBOARD -->

        <div class="row admin-dashboard">
            <div class="col-12">
                <h1>Administrador</h1>
            </div>
            
            <div class="col-12 col-btn-right">
                <a href="./admin_agregar_derecho.html" class="btn-repo btn-dashboard-agregar"><span><img src="../../imgs/svg/icon_new_document.svg" alt="documento"></span>Agregar</a>
                <a href="./admin_agregar_imagen.html" class="btn-repo btn-dashboard-agregar"><span><img src="../../imgs/svg/icon_new_img.svg" alt="documento"></span>Agregar</a> 
            </div>

            <div class="col-2">
                <a href="#" class="btn-repo">Documentos</a>
                <a href="#" class="btn-repo">Infografías</a>
                <a href="#" class="btn-repo">Fotografías</a>
            </div>

            <div class="col-10">
                <!--Tupla-->
                <div class="row tupla">
                    <div class="col-6">
                        <img src="../../imgs/svg/document_icon.svg" alt="documento">
                        <p>Título del documento</p>
                    </div>

                    <div class="col-2">
                        <p>25/04/21</p>
                    </div>
                    <div class="col-2">
                        <a href="#">Modificar</a>
                    </div>
                    <div class="col-2">
                        <a href="#">Eliminar</a>
                    </div>
                </div>

                <div class="row tupla">
                    <div class="col-6">
                        <img src="../../imgs/svg/document_icon.svg" alt="documento">
                        <p>Título del documento</p>
                    </div>

                    <div class="col-2">
                        <p>25/04/21</p>
                    </div>
                    <div class="col-2">
                        <a href="#">Modificar</a>
                    </div>
                    <div class="col-2">
                        <a href="#">Eliminar</a>
                    </div>
                </div>

                <div class="row tupla">
                    <div class="col-6">
                        <img src="../../imgs/svg/document_icon.svg" alt="documento">
                        <p>Título del documento</p>
                    </div>

                    <div class="col-2">
                        <p>25/04/21</p>
                    </div>
                    <div class="col-2">
                        <a href="#">Modificar</a>
                    </div>
                    <div class="col-2">
                        <a href="#">Eliminar</a>
                    </div>
                </div>

                <div class="row tupla">
                    <div class="col-6">
                        <img src="../../imgs/svg/document_icon.svg" alt="documento">
                        <p>Título del documento</p>
                    </div>

                    <div class="col-2">
                        <p>25/04/21</p>
                    </div>
                    <div class="col-2">
                        <a href="#">Modificar</a>
                    </div>
                    <div class="col-2">
                        <a href="#">Eliminar</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- DASHBOARD -->

        <!-- FOTTER -->
        <footer class="row footer">
            <div class="col-sm left-text">
                <p>©2021</p>
                <p>Todos los derechos reservados</p>
            </div>
            <div class="col-sm icons-footer">
                <img src="../../imgs/svg/icon_punto-violeta.svg" alt="Logo Punto Violeta">
            </div>
            <div class="col-sm icons-footer">
                <img src="../../imgs/svg/icon_ret.svg" alt="Logo RET">
            </div> 
            <div class="col-sm right-text">
                <p>By Willy Lara Campos</p>
                <p>By Ronald Chaves González</p>
                <p>By Benjamín Álvarez Rodríguez</p>
            </div>
        </footer>
        <!-- FOTTER -->

    </section>

    <script src="./js/main.js"></script>

</body>

</html><?php /**PATH B:\laragon\www\puntovioletaret\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>